package handler

import (
	"encoding/base64"
	"net/http"

	"github.com/go-playground/validator/v10"
	"github.com/mosinaRZ/finance-sync-backend/internal/domain/apperror"
	"github.com/mosinaRZ/finance-sync-backend/internal/domain/entity"
	"github.com/mosinaRZ/finance-sync-backend/internal/interface/http/contextkeys"
	"github.com/mosinaRZ/finance-sync-backend/internal/interface/http/dto"
	"github.com/mosinaRZ/finance-sync-backend/internal/pkg/response"
	"github.com/mosinaRZ/finance-sync-backend/internal/usecase/auth"
)

type AuthHandler struct {
	usecase  auth.Service
	otp      auth.OTPService
	validate *validator.Validate
}

func NewAuthHandler(u auth.Service, v *validator.Validate, otp ...auth.OTPService) *AuthHandler {
	var o auth.OTPService
	if len(otp) > 0 {
		o = otp[0]
	}
	if v == nil {
		v = validator.New()
	}
	return &AuthHandler{usecase: u, otp: o, validate: v}
}
func (h *AuthHandler) RequestOTP(w http.ResponseWriter, r *http.Request) {
	var q dto.OTPRequest
	if err := decodeJSON(w, r, &q); err != nil {
		response.Error(w, err)
		return
	}
	if err := validateRequest(h.validate, q); err != nil {
		response.Error(w, err)
		return
	}
	out, err := h.otp.Request(r.Context(), auth.RequestOTPInput{Destination: q.Destination, Channel: q.Channel, Purpose: entity.OTPPurpose(q.Purpose)})
	if err != nil {
		response.Error(w, err)
		return
	}
	response.JSON(w, http.StatusOK, dto.OTPResponse{ChallengeID: out.ChallengeID, ExpiresAt: out.ExpiresAt})
}
func (h *AuthHandler) Register(w http.ResponseWriter, r *http.Request) {
	var q dto.RegisterRequest
	if err := decodeJSON(w, r, &q); err != nil {
		response.Error(w, err)
		return
	}
	if err := validateRequest(h.validate, q); err != nil {
		response.Error(w, err)
		return
	}
	passwordKeyEnvelope, err := decodeB64(q.PasswordKeyEnvelope)
	if err != nil {
		response.Error(w, apperror.ErrValidation("password_key_envelope must be valid base64"))
		return
	}
	passwordKeyNonce, err := decodeB64(q.PasswordKeyNonce)
	if err != nil {
		response.Error(w, apperror.ErrValidation("password_key_nonce must be valid base64"))
		return
	}
	recoveryKeyEnvelope, err := decodeB64(q.RecoveryKeyEnvelope)
	if err != nil {
		response.Error(w, apperror.ErrValidation("recovery_key_envelope must be valid base64"))
		return
	}
	recoveryKeyNonce, err := decodeB64(q.RecoveryKeyNonce)
	if err != nil {
		response.Error(w, apperror.ErrValidation("recovery_key_nonce must be valid base64"))
		return
	}
	recoveryKeyHash, err := decodeRecoveryHash(q.RecoveryKeyHash)
	if err != nil {
		response.Error(w, apperror.ErrValidation("recovery_key_hash must be valid base64"))
		return
	}

	in := auth.RegisterInput{
		PhoneNumber:         q.PhoneNumber,
		AuthSecret:          q.AuthSecret,
		DeviceID:            q.DeviceID,
		OTPChallengeID:      q.OTPChallengeID,
		OTPCode:             q.OTPCode,
		KdfSalt:             q.KdfSalt,
		PasswordKeyEnvelope: passwordKeyEnvelope,
		PasswordKeyNonce:    passwordKeyNonce,
		RecoveryKeyHash:     recoveryKeyHash,
		RecoveryKeyEnvelope: recoveryKeyEnvelope,
		RecoveryKeyNonce:    recoveryKeyNonce,
		Device:              deviceInfoFrom(r, q.DeviceInfo),
	}
	out, err := h.usecase.Register(r.Context(), in)
	if err != nil {
		response.Error(w, err)
		return
	}
	response.JSON(w, http.StatusCreated, dto.RegisterResponse{AccessToken: out.AccessToken, RefreshToken: out.RefreshToken, KdfSalt: out.KdfSalt, UserID: out.UserID, RecoveryRequired: out.RecoveryRequired, PasswordKeyEnvelope: enc(out.PasswordKeyEnvelope), PasswordKeyNonce: enc(out.PasswordKeyNonce), RecoveryKeyEnvelope: enc(out.RecoveryKeyEnvelope), RecoveryKeyNonce: enc(out.RecoveryKeyNonce), Role: out.Role})
}

// LoginParams returns the public KDF parameters for an identifier (see dto.LoginParamsResponse).
func (h *AuthHandler) LoginParams(w http.ResponseWriter, r *http.Request) {
	var q dto.LoginParamsRequest
	if err := decodeJSON(w, r, &q); err != nil {
		response.Error(w, err)
		return
	}
	if err := validateRequest(h.validate, q); err != nil {
		response.Error(w, err)
		return
	}
	out, err := h.usecase.LoginParams(r.Context(), q.Identifier)
	if err != nil {
		response.Error(w, err)
		return
	}
	response.JSON(w, http.StatusOK, dto.LoginParamsResponse{KdfSalt: out.KdfSalt, KdfIterations: out.KdfIterations, KdfVersion: out.KdfVersion})
}

func (h *AuthHandler) Login(w http.ResponseWriter, r *http.Request) {
	var q dto.LoginRequest
	if err := decodeJSON(w, r, &q); err != nil {
		response.Error(w, err)
		return
	}
	if err := validateRequest(h.validate, q); err != nil {
		response.Error(w, err)
		return
	}
	out, err := h.usecase.Login(r.Context(), auth.LoginInput{Identifier: q.Identifier, AuthSecret: q.AuthSecret, DeviceID: q.DeviceID, RestoreAccount: q.RestoreAccount, Device: deviceInfoFrom(r, q.DeviceInfo)})
	if err != nil {
		response.Error(w, err)
		return
	}
	response.JSON(w, http.StatusOK, dto.LoginResponse{AccessToken: out.AccessToken, RefreshToken: out.RefreshToken, KdfSalt: out.KdfSalt, UserID: out.UserID, PasswordKeyEnvelope: enc(out.PasswordKeyEnvelope), PasswordKeyNonce: enc(out.PasswordKeyNonce), RecoveryKeyEnvelope: enc(out.RecoveryKeyEnvelope), RecoveryKeyNonce: enc(out.RecoveryKeyNonce), Role: out.Role})
}
func (h *AuthHandler) Refresh(w http.ResponseWriter, r *http.Request) {
	var q dto.RefreshRequest
	if err := decodeJSON(w, r, &q); err != nil {
		response.Error(w, err)
		return
	}
	if err := validateRequest(h.validate, q); err != nil {
		response.Error(w, err)
		return
	}
	out, err := h.usecase.Refresh(r.Context(), auth.RefreshInput{RefreshToken: q.RefreshToken})
	if err != nil {
		response.Error(w, err)
		return
	}
	response.JSON(w, http.StatusOK, dto.RefreshResponse{AccessToken: out.AccessToken, RefreshToken: out.RefreshToken, Role: out.Role})
}
func (h *AuthHandler) PrepareRecovery(w http.ResponseWriter, r *http.Request) {
	var q dto.PrepareRecoveryRequest
	if err := decodeJSON(w, r, &q); err != nil {
		response.Error(w, err)
		return
	}
	if err := validateRequest(h.validate, q); err != nil {
		response.Error(w, err)
		return
	}
	extended, ok := h.usecase.(auth.ExtendedService)
	if !ok {
		response.Error(w, apperror.ErrInternal("recovery service is not configured"))
		return
	}
	out, err := extended.PrepareRecovery(r.Context(), auth.PrepareRecoveryInput{ChallengeID: q.OTPChallengeID, OTPCode: q.OTPCode, RecoveryProof: q.RecoveryProof})
	if err != nil {
		response.Error(w, err)
		return
	}
	response.JSON(w, http.StatusOK, dto.PrepareRecoveryResponse{RecoverySessionToken: out.RecoverySessionToken, KdfSalt: out.KdfSalt, UserID: out.UserID, RecoveryKeyEnvelope: enc(out.RecoveryKeyEnvelope), RecoveryKeyNonce: enc(out.RecoveryKeyNonce)})
}

func (h *AuthHandler) ResetPassword(w http.ResponseWriter, r *http.Request) {
	var q dto.ResetPasswordRequest
	if err := decodeJSON(w, r, &q); err != nil {
		response.Error(w, err)
		return
	}
	if err := validateRequest(h.validate, q); err != nil {
		response.Error(w, err)
		return
	}
	extended, ok := h.usecase.(auth.ExtendedService)
	if !ok {
		response.Error(w, apperror.ErrInternal("password reset service is not configured"))
		return
	}
	passwordKeyEnvelope, err := decodeB64(q.PasswordKeyEnvelope)
	if err != nil {
		response.Error(w, apperror.ErrValidation("password_key_envelope must be valid base64"))
		return
	}
	passwordKeyNonce, err := decodeB64(q.PasswordKeyNonce)
	if err != nil {
		response.Error(w, apperror.ErrValidation("password_key_nonce must be valid base64"))
		return
	}
	out, err := extended.ResetPassword(r.Context(), auth.ResetPasswordInput{RecoverySessionToken: q.RecoverySessionToken, NewAuthSecret: q.NewAuthSecret, DeviceID: q.DeviceID, KdfSalt: q.KdfSalt, PasswordKeyEnvelope: passwordKeyEnvelope, PasswordKeyNonce: passwordKeyNonce, Device: deviceInfoFrom(r, q.DeviceInfo)})
	if err != nil {
		response.Error(w, err)
		return
	}
	response.JSON(w, http.StatusOK, dto.ResetPasswordResponse{AccessToken: out.AccessToken, RefreshToken: out.RefreshToken, KdfSalt: out.KdfSalt, UserID: out.UserID, PasswordKeyEnvelope: enc(out.PasswordKeyEnvelope), PasswordKeyNonce: enc(out.PasswordKeyNonce), RecoveryKeyEnvelope: enc(out.RecoveryKeyEnvelope), RecoveryKeyNonce: enc(out.RecoveryKeyNonce), Role: out.Role})
}

// ChangePassword changes the password of the authenticated user (route is behind Auth).
func (h *AuthHandler) GetProfile(w http.ResponseWriter, r *http.Request) {
	userID, ok := contextkeys.UserID(r.Context())
	if !ok || userID == "" {
		response.Error(w, apperror.ErrUnauthorized("authentication required"))
		return
	}
	service, ok := h.usecase.(auth.ProfileService)
	if !ok {
		response.Error(w, apperror.ErrInternal("profile service is not configured"))
		return
	}
	out, err := service.GetProfile(r.Context(), userID)
	if err != nil {
		response.Error(w, err)
		return
	}
	response.JSON(w, http.StatusOK, dto.ProfileResponse{
		UserID: out.UserID, PhoneNumber: out.PhoneNumber, FirstName: out.FirstName, LastName: out.LastName,
		Gender: out.Gender, BirthDate: out.BirthDate,
	})
}

func (h *AuthHandler) UpdateProfile(w http.ResponseWriter, r *http.Request) {
	userID, ok := contextkeys.UserID(r.Context())
	if !ok || userID == "" {
		response.Error(w, apperror.ErrUnauthorized("authentication required"))
		return
	}
	var q dto.UpdateProfileRequest
	if err := decodeJSON(w, r, &q); err != nil {
		response.Error(w, err)
		return
	}
	if err := validateRequest(h.validate, q); err != nil {
		response.Error(w, err)
		return
	}
	service, ok := h.usecase.(auth.ProfileService)
	if !ok {
		response.Error(w, apperror.ErrInternal("profile service is not configured"))
		return
	}
	out, err := service.UpdateProfile(r.Context(), auth.UpdateProfileInput{
		UserID: userID, FirstName: q.FirstName, LastName: q.LastName,
		Gender: q.Gender, BirthDate: q.BirthDate,
	})
	if err != nil {
		response.Error(w, err)
		return
	}
	response.JSON(w, http.StatusOK, dto.ProfileResponse{
		UserID: out.UserID, PhoneNumber: out.PhoneNumber, FirstName: out.FirstName, LastName: out.LastName,
		Gender: out.Gender, BirthDate: out.BirthDate,
	})
}

func (h *AuthHandler) ChangePassword(w http.ResponseWriter, r *http.Request) {
	userID, ok := contextkeys.UserID(r.Context())
	if !ok || userID == "" {
		response.Error(w, apperror.ErrUnauthorized("authentication required"))
		return
	}
	var q dto.ChangePasswordRequest
	if err := decodeJSON(w, r, &q); err != nil {
		response.Error(w, err)
		return
	}
	if err := validateRequest(h.validate, q); err != nil {
		response.Error(w, err)
		return
	}
	changer, ok := h.usecase.(auth.PasswordChanger)
	if !ok {
		response.Error(w, apperror.ErrInternal("password change service is not configured"))
		return
	}
	passwordKeyEnvelope, err := decodeB64(q.PasswordKeyEnvelope)
	if err != nil {
		response.Error(w, apperror.ErrValidation("password_key_envelope must be valid base64"))
		return
	}
	passwordKeyNonce, err := decodeB64(q.PasswordKeyNonce)
	if err != nil {
		response.Error(w, apperror.ErrValidation("password_key_nonce must be valid base64"))
		return
	}
	out, err := changer.ChangePassword(r.Context(), auth.ChangePasswordInput{
		UserID: userID, CurrentAuthSecret: q.CurrentAuthSecret, NewAuthSecret: q.NewAuthSecret, DeviceID: q.DeviceID,
		KdfSalt: q.KdfSalt, PasswordKeyEnvelope: passwordKeyEnvelope, PasswordKeyNonce: passwordKeyNonce,
		Device: deviceInfoFrom(r, q.DeviceInfo),
	})
	if err != nil {
		response.Error(w, err)
		return
	}
	response.JSON(w, http.StatusOK, dto.ChangePasswordResponse{AccessToken: out.AccessToken, RefreshToken: out.RefreshToken, KdfSalt: out.KdfSalt, UserID: out.UserID, Role: out.Role, PasswordKeyEnvelope: enc(out.PasswordKeyEnvelope), PasswordKeyNonce: enc(out.PasswordKeyNonce), RecoveryKeyEnvelope: enc(out.RecoveryKeyEnvelope), RecoveryKeyNonce: enc(out.RecoveryKeyNonce)})
}

// DeleteAccount soft-deletes the authenticated user's account (route is behind Auth).
func (h *AuthHandler) DeleteAccount(w http.ResponseWriter, r *http.Request) {
	userID, ok := contextkeys.UserID(r.Context())
	if !ok || userID == "" {
		response.Error(w, apperror.ErrUnauthorized("authentication required"))
		return
	}
	var q dto.DeleteAccountRequest
	if err := decodeJSON(w, r, &q); err != nil {
		response.Error(w, err)
		return
	}
	if err := validateRequest(h.validate, q); err != nil {
		response.Error(w, err)
		return
	}
	deleter, ok := h.usecase.(auth.AccountDeleter)
	if !ok {
		response.Error(w, apperror.ErrInternal("account deletion service is not configured"))
		return
	}
	out, err := deleter.DeleteAccount(r.Context(), auth.DeleteAccountInput{UserID: userID, AuthSecret: q.AuthSecret})
	if err != nil {
		response.Error(w, err)
		return
	}
	response.JSON(w, http.StatusOK, dto.DeleteAccountResponse{DeletedAtMs: out.DeletedAt.UnixMilli(), RestorableUntilMs: out.RestorableUntil.UnixMilli()})
}

// deviceInfoFrom merges the optional client-supplied description with the client IP
// resolved by trusted middleware. The IP is never read from the request body.
func deviceInfoFrom(r *http.Request, in *dto.DeviceInfoRequest) auth.DeviceInfo {
	info := auth.DeviceInfo{}
	if in != nil {
		info = auth.DeviceInfo{Name: in.Name, Model: in.Model, Platform: in.Platform, OSVersion: in.OSVersion, AppVersion: in.AppVersion, Fingerprint: in.Fingerprint}
	}
	if ip, ok := contextkeys.ClientIP(r.Context()); ok {
		info.IP = ip
	}
	return info
}

func enc(b []byte) string {
	if len(b) == 0 {
		return ""
	}
	return base64.StdEncoding.EncodeToString(b)
}
func decodeB64(s string) ([]byte, error) {
	if s == "" {
		return nil, nil
	}
	b, err := base64.StdEncoding.DecodeString(s)
	if err != nil {
		return nil, err
	}
	return b, nil
}

func decodeRecoveryHash(s string) ([]byte, error) {
	if s == "" {
		return nil, nil
	}
	if b, err := base64.StdEncoding.DecodeString(s); err == nil {
		return b, nil
	}
	return base64.RawURLEncoding.DecodeString(s)
}

func (h *AuthHandler) Logout(w http.ResponseWriter, r *http.Request) {
	var q dto.LogoutRequest
	if err := decodeJSON(w, r, &q); err != nil {
		response.Error(w, err)
		return
	}
	if err := validateRequest(h.validate, q); err != nil {
		response.Error(w, err)
		return
	}
	extended, ok := h.usecase.(auth.ExtendedService)
	if !ok {
		response.Error(w, apperror.ErrInternal("logout service is not configured"))
		return
	}
	if err := extended.Logout(r.Context(), q.RefreshToken); err != nil {
		response.Error(w, err)
		return
	}
	w.WriteHeader(http.StatusNoContent)
}
