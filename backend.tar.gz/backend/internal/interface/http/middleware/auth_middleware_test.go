package middleware

import (
	"context"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
	"time"

	"github.com/mosinaRZ/finance-sync-backend/internal/domain/apperror"
	"github.com/mosinaRZ/finance-sync-backend/internal/domain/entity"
	infraauth "github.com/mosinaRZ/finance-sync-backend/internal/infrastructure/auth"
	"github.com/mosinaRZ/finance-sync-backend/internal/interface/http/contextkeys"
	"github.com/mosinaRZ/finance-sync-backend/internal/usecase/mocks"
)

func TestAuthMiddlewareRejectsMissingToken(t *testing.T) {
	nextCalled := false
	h := Auth("01234567890123456789012345678901", &mocks.MockUserRepository{})(http.HandlerFunc(func(http.ResponseWriter, *http.Request) { nextCalled = true }))
	req := httptest.NewRequest(http.MethodPost, "/api/v1/sync", nil)
	rec := httptest.NewRecorder()
	h.ServeHTTP(rec, req)
	if rec.Code != http.StatusUnauthorized || nextCalled {
		t.Fatalf("status=%d nextCalled=%v", rec.Code, nextCalled)
	}
}

func TestAuthMiddlewareRejectsExpiredToken(t *testing.T) {
	secret := "01234567890123456789012345678901"
	token, err := infraauth.GenerateAccessToken("user-1", time.Nanosecond, secret)
	if err != nil {
		t.Fatal(err)
	}
	time.Sleep(2 * time.Millisecond)
	h := Auth(secret, &mocks.MockUserRepository{})(http.HandlerFunc(func(http.ResponseWriter, *http.Request) { t.Fatal("next should not be called") }))
	req := httptest.NewRequest(http.MethodPost, "/api/v1/sync", nil)
	req.Header.Set("Authorization", "Bearer "+token)
	rec := httptest.NewRecorder()
	h.ServeHTTP(rec, req)
	if rec.Code != http.StatusUnauthorized {
		t.Fatalf("status=%d, want 401", rec.Code)
	}
}

func TestAuthMiddlewareStoresOnlyValidatedUserIDInContext(t *testing.T) {
	secret := "01234567890123456789012345678901"
	token, err := infraauth.GenerateAccessToken("user-1", time.Minute, secret)
	if err != nil {
		t.Fatal(err)
	}
	var got string
	h := Auth(secret, &mocks.MockUserRepository{})(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		got, _ = contextkeys.UserID(r.Context())
		w.WriteHeader(http.StatusNoContent)
	}))
	req := httptest.NewRequest(http.MethodPost, "/api/v1/sync", nil)
	req.Header.Set("Authorization", "Bearer "+token)
	rec := httptest.NewRecorder()
	h.ServeHTTP(rec, req)
	if rec.Code != http.StatusNoContent || got != "user-1" {
		t.Fatalf("status=%d userID=%q", rec.Code, got)
	}
}

func TestRequireRolesRejectsNonAdmin(t *testing.T) {
	secret := "01234567890123456789012345678901"
	token, err := infraauth.GenerateAccessToken("user-1", time.Minute, secret)
	if err != nil {
		t.Fatal(err)
	}
	r := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(http.StatusNoContent)
	})
	req := httptest.NewRequest(http.MethodGet, "/admin", nil)
	req.Header.Set("Authorization", "Bearer "+token)
	rec := httptest.NewRecorder()
	Auth(secret, &mocks.MockUserRepository{})(RequireRoles(entity.RoleAdmin)(r)).ServeHTTP(rec, req)
	if rec.Code != http.StatusForbidden {
		t.Fatalf("status = %d, want 403", rec.Code)
	}
}

func TestAuthMiddlewareRejectsRevokedSessionVersion(t *testing.T) {
	secret := "01234567890123456789012345678901"
	token, err := infraauth.GenerateAccessTokenWithRoleAndSession("user-1", entity.RoleUser, 4, time.Minute, secret)
	if err != nil {
		t.Fatal(err)
	}
	users := &mocks.MockUserRepository{GetSessionVersionFunc: func(context.Context, string) (uint64, error) { return 5, nil }}
	h := Auth(secret, users)(http.HandlerFunc(func(http.ResponseWriter, *http.Request) { t.Fatal("revoked token reached handler") }))
	req := httptest.NewRequest(http.MethodGet, "/api/v1/sync", nil)
	req.Header.Set("Authorization", "Bearer "+token)
	rec := httptest.NewRecorder()
	h.ServeHTTP(rec, req)
	if rec.Code != http.StatusUnauthorized {
		t.Fatalf("status=%d, want 401", rec.Code)
	}
}

func TestRequireRolesAllowsAdmin(t *testing.T) {
	secret := "01234567890123456789012345678901"
	token, err := infraauth.GenerateAccessTokenWithRole("admin-1", entity.RoleAdmin, time.Minute, secret)
	if err != nil {
		t.Fatal(err)
	}
	r := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if role, ok := contextkeys.Role(r.Context()); !ok || role != string(entity.RoleAdmin) {
			t.Fatalf("role in context = %q, %v", role, ok)
		}
		w.WriteHeader(http.StatusNoContent)
	})
	req := httptest.NewRequest(http.MethodGet, "/admin", nil)
	req.Header.Set("Authorization", "Bearer "+token)
	rec := httptest.NewRecorder()
	Auth(secret, &mocks.MockUserRepository{})(RequireRoles(entity.RoleAdmin)(r)).ServeHTTP(rec, req)
	if rec.Code != http.StatusNoContent {
		t.Fatalf("status = %d, want 204", rec.Code)
	}
}

func TestAuthWithDevicesRejectsRemovedDevice(t *testing.T) {
	secret := "01234567890123456789012345678901"
	token, err := infraauth.GenerateAccessTokenForDevice("user-1", entity.RoleUser, 0, "device-1", time.Minute, secret)
	if err != nil {
		t.Fatal(err)
	}
	devices := &mocks.MockDeviceRepository{ExistsFunc: func(_ context.Context, u, d string) (bool, error) {
		return !(u == "user-1" && d == "device-1"), nil // device-1 has been removed
	}}
	h := AuthWithDevices(secret, &mocks.MockUserRepository{}, devices)(http.HandlerFunc(func(http.ResponseWriter, *http.Request) {
		t.Fatal("removed device reached handler")
	}))
	req := httptest.NewRequest(http.MethodGet, "/api/v1/account/profile", nil)
	req.Header.Set("Authorization", "Bearer "+token)
	rec := httptest.NewRecorder()
	h.ServeHTTP(rec, req)
	if rec.Code != http.StatusUnauthorized {
		t.Fatalf("status=%d, want 401", rec.Code)
	}
	// Clients rely on this code to tell "device removed" apart from an ordinary expired session.
	if !strings.Contains(rec.Body.String(), "DEVICE_REMOVED") {
		t.Fatalf("body=%s, want DEVICE_REMOVED error code", rec.Body.String())
	}
}

func TestAuthWithDevicesAllowsRegisteredDeviceAndExposesIt(t *testing.T) {
	secret := "01234567890123456789012345678901"
	token, err := infraauth.GenerateAccessTokenForDevice("user-1", entity.RoleUser, 0, "device-1", time.Minute, secret)
	if err != nil {
		t.Fatal(err)
	}
	devices := &mocks.MockDeviceRepository{ExistsFunc: func(context.Context, string, string) (bool, error) { return true, nil }}
	var got string
	h := AuthWithDevices(secret, &mocks.MockUserRepository{}, devices)(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		got, _ = contextkeys.DeviceID(r.Context())
		w.WriteHeader(http.StatusNoContent)
	}))
	req := httptest.NewRequest(http.MethodGet, "/api/v1/devices", nil)
	req.Header.Set("Authorization", "Bearer "+token)
	rec := httptest.NewRecorder()
	h.ServeHTTP(rec, req)
	if rec.Code != http.StatusNoContent || got != "device-1" {
		t.Fatalf("status=%d device=%q", rec.Code, got)
	}
}

func TestAuthWithDevicesDoesNotSignOutOnStorageFailure(t *testing.T) {
	secret := "01234567890123456789012345678901"
	token, err := infraauth.GenerateAccessTokenForDevice("user-1", entity.RoleUser, 0, "device-1", time.Minute, secret)
	if err != nil {
		t.Fatal(err)
	}
	devices := &mocks.MockDeviceRepository{ExistsFunc: func(context.Context, string, string) (bool, error) {
		return false, apperror.ErrInternal("db down")
	}}
	h := AuthWithDevices(secret, &mocks.MockUserRepository{}, devices)(http.HandlerFunc(func(http.ResponseWriter, *http.Request) {
		t.Fatal("handler must not run when device state is unknown")
	}))
	req := httptest.NewRequest(http.MethodGet, "/api/v1/devices", nil)
	req.Header.Set("Authorization", "Bearer "+token)
	rec := httptest.NewRecorder()
	h.ServeHTTP(rec, req)
	if rec.Code != http.StatusInternalServerError {
		t.Fatalf("status=%d, want 500 (must not look like a removed device)", rec.Code)
	}
}
