package mongodb

import (
	"context"
	"errors"
	"fmt"
	"time"

	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
)

func EnsureIndexes(ctx context.Context, db *mongo.Database) error {
	ctx, cancel := context.WithTimeout(ctx, 30*time.Second)
	defer cancel()
	if _, err := db.Collection(syncRecordsCollectionName).Indexes().CreateMany(ctx, []mongo.IndexModel{
		{Keys: bson.D{{Key: "userId", Value: 1}, {Key: "entityType", Value: 1}, {Key: "entityId", Value: 1}}, Options: options.Index().SetUnique(true).SetName("uniq_sync_identity")},
		{Keys: bson.D{{Key: "userId", Value: 1}, {Key: "serverRevision", Value: 1}}, Options: options.Index().SetName("idx_sync_cursor")},
	}); err != nil {
		return fmt.Errorf("sync_records indexes: %w", err)
	}
	if _, err := db.Collection(syncOperationsCollectionName).Indexes().CreateMany(ctx, []mongo.IndexModel{
		{Keys: bson.D{{Key: "userId", Value: 1}, {Key: "requestId", Value: 1}}, Options: options.Index().SetUnique(true).SetName("uniq_sync_request")},
		{Keys: bson.D{{Key: "createdAt", Value: 1}}, Options: options.Index().SetExpireAfterSeconds(7 * 24 * 3600).SetName("ttl_sync_operations")},
	}); err != nil {
		return fmt.Errorf("sync_operations indexes: %w", err)
	}
	if _, err := db.Collection(syncRevisionCountersCollectionName).Indexes().CreateOne(ctx, mongo.IndexModel{Keys: bson.D{{Key: "_id", Value: 1}}, Options: options.Index().SetName("uniq_sync_revision_counter")}); err != nil {
		return fmt.Errorf("sync_revision_counters indexes: %w", err)
	}
	// Remove legacy optional account-contact properties from existing records and drop their old index.
	if _, err := db.Collection(usersCollectionName).UpdateMany(ctx, bson.M{}, bson.M{"$unset": bson.M{"email": "", "emailHash": "", "emailVerified": ""}}); err != nil {
		return fmt.Errorf("remove obsolete user fields: %w", err)
	}
	if _, err := db.Collection(usersCollectionName).
		Indexes().
		DropOne(ctx, "uniq_user_email_hash"); err != nil {
		if !isMissingIndexOrNamespace(err) {
			return fmt.Errorf("drop obsolete user index: %w", err)
		}
	}
	if _, err := db.Collection(usersCollectionName).Indexes().CreateMany(ctx, []mongo.IndexModel{
		{Keys: bson.D{{Key: "phoneHash", Value: 1}}, Options: options.Index().SetUnique(true).SetSparse(true).SetName("uniq_user_phone_hash")},
		// Lets the purge job find expired soft-deleted accounts without scanning the collection.
		{Keys: bson.D{{Key: "isDeleted", Value: 1}, {Key: "deletedAt", Value: 1}}, Options: options.Index().SetPartialFilterExpression(bson.M{"isDeleted": true}).SetName("idx_user_deleted")},
	}); err != nil {
		return fmt.Errorf("users indexes: %w", err)
	}
	if _, err := db.Collection(refreshTokensCollectionName).Indexes().CreateMany(ctx, []mongo.IndexModel{
		{Keys: bson.D{{Key: "tokenHash", Value: 1}}, Options: options.Index().SetUnique(true).SetName("uniq_refresh_token_hash")},
		{Keys: bson.D{{Key: "userId", Value: 1}, {Key: "revokedAt", Value: 1}}, Options: options.Index().SetName("idx_refresh_user_revoked")},
		{Keys: bson.D{{Key: "expiresAt", Value: 1}}, Options: options.Index().SetExpireAfterSeconds(0).SetName("ttl_refresh_tokens")},
	}); err != nil {
		return fmt.Errorf("refresh_tokens indexes: %w", err)
	}
	if _, err := db.Collection(otpCollectionName).Indexes().CreateMany(ctx, []mongo.IndexModel{
		{Keys: bson.D{{Key: "expiresAt", Value: 1}}, Options: options.Index().SetExpireAfterSeconds(0).SetName("ttl_otp")},
		{Keys: bson.D{{Key: "destinationHash", Value: 1}, {Key: "channel", Value: 1}, {Key: "purpose", Value: 1}, {Key: "createdAt", Value: -1}}, Options: options.Index().SetName("idx_otp_rate")},
	}); err != nil {
		return fmt.Errorf("otp indexes: %w", err)
	}
	if _, err := db.Collection(recoverySessionsCollectionName).Indexes().CreateMany(ctx, []mongo.IndexModel{
		{Keys: bson.D{{Key: "tokenHash", Value: 1}}, Options: options.Index().SetUnique(true).SetName("uniq_recovery_session_token")},
		{Keys: bson.D{{Key: "expiresAt", Value: 1}}, Options: options.Index().SetExpireAfterSeconds(0).SetName("ttl_recovery_sessions")},
	}); err != nil {
		return fmt.Errorf("recovery_sessions indexes: %w", err)
	}
	if _, err := db.Collection(auditLogsCollectionName).Indexes().CreateMany(ctx, []mongo.IndexModel{
		{Keys: bson.D{{Key: "targetUserId", Value: 1}, {Key: "createdAt", Value: -1}}, Options: options.Index().SetName("idx_audit_target_created")},
	}); err != nil {
		return fmt.Errorf("audit_logs indexes: %w", err)
	}
	if _, err := db.Collection(devicesCollectionName).Indexes().CreateMany(ctx, []mongo.IndexModel{
		{Keys: bson.D{{Key: "userId", Value: 1}, {Key: "deviceId", Value: 1}}, Options: options.Index().SetUnique(true).SetName("uniq_device")},
		{Keys: bson.D{{Key: "userId", Value: 1}, {Key: "lastSeenAt", Value: -1}}, Options: options.Index().SetName("idx_device_last_seen")},
		{Keys: bson.D{{Key: "userId", Value: 1}, {Key: "createdAt", Value: 1}, {Key: "deviceId", Value: 1}}, Options: options.Index().SetName("idx_device_created")},
		{Keys: bson.D{{Key: "userId", Value: 1}, {Key: "fingerprint", Value: 1}}, Options: options.Index().SetSparse(true).SetName("idx_device_fingerprint")},
	}); err != nil {
		return fmt.Errorf("devices indexes: %w", err)
	}
	if _, err := db.Collection(deviceEventsCollectionName).Indexes().CreateMany(ctx, []mongo.IndexModel{
		{Keys: bson.D{{Key: "userId", Value: 1}, {Key: "createdAt", Value: 1}}, Options: options.Index().SetName("idx_device_event_user_created")},
		// Device activity is only useful for a while; MongoDB expires old entries on its own.
		{Keys: bson.D{{Key: "createdAt", Value: 1}}, Options: options.Index().SetName("ttl_device_event_created").SetExpireAfterSeconds(int32(deviceEventTTL / time.Second))},
	}); err != nil {
		return fmt.Errorf("device_events indexes: %w", err)
	}
	return nil
}

// isMissingIndexOrNamespace reports whether a DropOne error only means there is
// nothing to drop: IndexNotFound (27), or NamespaceNotFound (26) on a fresh database.
func isMissingIndexOrNamespace(err error) bool {
	var cmdErr mongo.CommandError
	if errors.As(err, &cmdErr) {
		return cmdErr.Code == 26 || cmdErr.Code == 27
	}
	return false
}
