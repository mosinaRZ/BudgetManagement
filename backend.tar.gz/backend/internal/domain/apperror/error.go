// Package apperror defines the application's transport-independent error categories.
// HTTP status mapping belongs to the HTTP interface layer.
package apperror

import (
	"errors"
	"fmt"
)

type Code string

const (
	CodeValidation   Code = "VALIDATION_ERROR"
	CodeBadRequest   Code = "BAD_REQUEST"
	CodeUnauthorized Code = "UNAUTHORIZED"
	CodeForbidden    Code = "FORBIDDEN"
	CodeNotFound     Code = "NOT_FOUND"
	CodeConflict     Code = "CONFLICT"
	CodeRateLimited  Code = "RATE_LIMITED"
	CodeInternal     Code = "INTERNAL_ERROR"
)

// CodeInvalidPassword means the caller is authenticated but supplied a wrong
// *current* password for a sensitive operation. It is deliberately distinct from
// CodeUnauthorized so clients never mistake it for an expired session.
const CodeInvalidPassword Code = "INVALID_PASSWORD"

// CodePrimaryDeviceProtected means the caller tried to remove the account's primary
// (first-registered) device from a different device. Clients show a dedicated message
// instead of treating it as a generic permission error.
const CodePrimaryDeviceProtected Code = "PRIMARY_DEVICE_PROTECTED"

// CodeDeviceRemovalForbidden means the caller tried to remove another device from a device
// that is not the account's primary device. Only the primary (first-registered) device may
// remove other devices; every device may still sign itself out.
const CodeDeviceRemovalForbidden Code = "DEVICE_REMOVAL_FORBIDDEN"

// CodeDeviceRemoved means the access token itself is still valid but the device it was issued
// to has been removed from the account. It is deliberately distinct from CodeUnauthorized so
// the client can tell the user *why* they were signed out instead of showing a generic
// "session expired" message. The HTTP status is still 401.
const CodeDeviceRemoved Code = "DEVICE_REMOVED"

// CodeAccountDeleted means the credentials are correct but the account was soft-deleted. It is
// only ever returned after the password was verified, so it cannot be used to probe which phone
// numbers are registered. Clients offer to restore the account while the grace period lasts.
const CodeAccountDeleted Code = "ACCOUNT_DELETED"

type AppError struct {
	Code    Code
	Message string
	Err     error
}

func (e *AppError) Error() string {
	if e == nil {
		return "<nil>"
	}
	if e.Err != nil {
		return fmt.Sprintf("%s: %s: %v", e.Code, e.Message, e.Err)
	}
	return fmt.Sprintf("%s: %s", e.Code, e.Message)
}

func (e *AppError) Unwrap() error { return e.Err }

func (e *AppError) Is(target error) bool {
	t, ok := target.(*AppError)
	return ok && e != nil && t != nil && e.Code == t.Code
}

func newAppError(code Code, message string, wrapped error) *AppError {
	return &AppError{Code: code, Message: message, Err: wrapped}
}

func ErrValidation(message string, wrapped ...error) *AppError {
	return newAppError(CodeValidation, message, firstOrNil(wrapped))
}
func ErrBadRequest(message string, wrapped ...error) *AppError {
	return newAppError(CodeBadRequest, message, firstOrNil(wrapped))
}
func ErrUnauthorized(message string, wrapped ...error) *AppError {
	return newAppError(CodeUnauthorized, message, firstOrNil(wrapped))
}
func ErrForbidden(message string, wrapped ...error) *AppError {
	return newAppError(CodeForbidden, message, firstOrNil(wrapped))
}
func ErrNotFound(message string, wrapped ...error) *AppError {
	return newAppError(CodeNotFound, message, firstOrNil(wrapped))
}
func ErrConflict(message string, wrapped ...error) *AppError {
	return newAppError(CodeConflict, message, firstOrNil(wrapped))
}
func ErrRateLimited(message string, wrapped ...error) *AppError {
	return newAppError(CodeRateLimited, message, firstOrNil(wrapped))
}
func ErrInvalidPassword(message string, wrapped ...error) *AppError {
	return newAppError(CodeInvalidPassword, message, firstOrNil(wrapped))
}
func ErrPrimaryDeviceProtected(message string, wrapped ...error) *AppError {
	return newAppError(CodePrimaryDeviceProtected, message, firstOrNil(wrapped))
}
func ErrDeviceRemovalForbidden(message string, wrapped ...error) *AppError {
	return newAppError(CodeDeviceRemovalForbidden, message, firstOrNil(wrapped))
}
func ErrDeviceRemoved(message string, wrapped ...error) *AppError {
	return newAppError(CodeDeviceRemoved, message, firstOrNil(wrapped))
}
func ErrAccountDeleted(message string, wrapped ...error) *AppError {
	return newAppError(CodeAccountDeleted, message, firstOrNil(wrapped))
}
func ErrInternal(message string, wrapped ...error) *AppError {
	return newAppError(CodeInternal, message, firstOrNil(wrapped))
}

func firstOrNil(errs []error) error {
	if len(errs) == 0 {
		return nil
	}
	return errs[0]
}

func CodeOf(err error) (Code, bool) {
	var appErr *AppError
	if !errors.As(err, &appErr) || appErr == nil {
		return "", false
	}
	return appErr.Code, true
}
